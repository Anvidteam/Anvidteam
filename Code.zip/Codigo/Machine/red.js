//console.log("Hello World");

document.write("<h1>Hello world xd<h1/>");

//console.error("Este es un ERROR"); 

function greeting(){
    console.log("Se ejecuta la funcion");

}
greeting(); greeting();
tf.tensor2d([1, 2, 3, 4], [2, 2]).print();
console.log(tf.tensor2d([1, 2, 3, 4], [2, 2]));
/*
const val = [];
for(i=0;i<30;i++){
    val[i]=Math.random(1,100)*100;
}
const tens = tf.tensor3d(val,[5,3,2], "int32");
tens.print();
//console.log(tens.data());
tens.data().then(function(res){
    console.log(res);
})
console.log(tens.dataSync());
*/

/*
const modelo = tf.sequential();

const oculta = tf.layers.dense({//capa oculta
    units: 4,//cantidad de nodos (neuronas)
    inputShape: [2],//num de entradas
    activation: 'sigmoid'
});

modelo.add(oculta);

const salida = tf.layers.dense({//capa de salida
    units: 1,//unidades de salida
    activation: 'sigmoid'
})

modelo.add(salida);
const learningRate = 0.2;
const sgdOptions = tf.train.sgd(learningRate);//optimizador

modelo.compile({//compilador
    optimizer: sgdOptions,
    loss: tf.losses.meanSquaredError
})
*/
//se aniaden datos
//se crean tensores
//tens1 su dim es de 2D con n colms, cada colm representa un valor de entrada
    //con datos conocidos
//tens2 es con datos desconocidos


console.log("IA comenzando a actuar")



async function learn(){
    const modelo = ytf.sequential();

    const oculta = tf.layers.dense({//capa oculta
        units: 1,//cantidad de nodos (neuronas)
        inputShape: [1],//num de entradas
        //activation: 'sigmoid'
    });
    modelo.add(oculta);
    
    //const learningRate = 0.2;
    //const sgdOptions = tf.train.sgd(learningRate);//optimizador
    modelo.compile({//compilador
        optimizer: 'sgd',
        loss: 'meanSquaredError'
    })

    
    const xs = tf.tensor2d([-1,0,1,2,3,4], [6,1]);
    const ys = tf.tensor2d([-3,-1,1,3,5,7], [6,1]);


    /*for(i=0; i<10; i++){//entrenamiento
        const respuesta = await modelo.fit(xs, ys,{shuffle: true, epochs: 100});
        console.log(respuesta.history.loss[0]);
    }*/
    await modelo.fit(xs, ys,{shuffle: true, epochs: 500});

    //document.getElementById('output_field').innerText = modelo.predict(tf.tensor2d([20], [1,1]));
    //document.write("<h1>En la IA<h1/>");
    const salida = modelo.predict(tf.tensor2d([20], [1,1]));
    salida.print();
    console.log(salida);
    
}
//learn();
/*.then(()=>{//iniciar la prediccion
    const salida = modelo.predict(tf.tensor2d([20], [1,1]));
    salida.print();
});*/

function convertToArrayX(isTrain, porcentajePruebas){
    //leer los csv y unirlos
    /*let reader = new FileReader();
    reader.readAsText(fileToRead);*/
    return null;
}

function convertToArrayY(isTrain, porcentajePruebas){
    //leer el csv
    return null;
}

function convertToTensors(data, targets, testSplit){
    const numExamples = data.length;
    if(numExamples != targets.length){
        throw new Error('data and split have different members of examples');
    }

    const numTestExamples = Math.round(numExamples*testSplit);
    const numTrainExamples = numExamples-numTestExamples;

    const xDims = data[0].length;
    //Se crea un 'tf.tensor' 2D para guardar los datos de las características
    const xs = tf.tensor2D(data, [numExamples,xDims])

    const ys = tf.oneHot(tf.tensor1d(targets).toInt)


    const xT = xs.slice([0, 0], [numTrainExamples, xDims]);
    const xP = xs.slice([numTrainExamples, 0], [numTestExamples, xDims]);
    const yT = ys.slice([0, 0], [numTrainExamples, numTipos]);
    const yP = ys.slice([0, 0], [numTestExamples, numTipos]);

    return [xT, yT, xP, yP];
}

var dataToral = [];
const tipoDatos = ["", "", "", "", "", ""];
const numTipos = tipoDatos.length;
function ejecutarInteligencia(porcentajePruebas){
    return tf.tidy(() => {
        const dataByClass = [];//datos por cada tipo de entrada
        const targetsByClass = [];
        for(let i=0; i<numTipos;++i){
            dataByClass.push([]);
            targetsByClass.push([]);
        }

        for(const example of dataTotal){
            const target = example[example.length-1];
            const data = example.slice(0, example.length-1);
            dataByClass[target].push(data);
            targetByClass[target].push(target);
        }

        /*const xTrains = convertToArrayY(true, porcentajePruebas);
        const yTrains = convertToArrayY(true, porcentajePruebas);
        const xPrueba = convertToArrayY(false, porcentajePruebas);
        const yPrueba = convertToArrayY(false, porcentajePruebas);*/
        
        for(let i=0; i<numTipos; ++i){
            const [xT,yT,xP,yP] = convertToTensors(dataByClass[i],targetsByClass[i],testSplit);
            xTrains.push(xT);
            yTrains.push(yT);
            xPrueba.push(xP);
            yPrueba.push(yP);
        }

        const concatAxis = 0;
        return [
            tf.concat(xTrains, concatAxis), tf.concat(yTrains, concatAxis), 
            tf.concat(xPrueba, concatAxis), tf.concat(yPrueba, concatAxis)
        ];
    });

}
//contagios = dato*w + b;
//tensor.dispose();//limpiar tensor
